package br.com.locaweb.relatorioclientes.DTO;



import java.time.LocalDateTime;

import lombok.*;

@Getter
@Setter
public class ExecucaoDTO {
    private Long id;
    private String nomeCliente;
    private String nomeMaquina; 
    private String descricaoProblema;
    private String descricao;
    private String observacoes;
    private LocalDateTime DataExecucao;
    private Long solicitacaoId;
    private Double valor;
    private String tecnico;
    private boolean pdfGerado;
    private boolean temFoto;
    private boolean emailEnviado;
}
