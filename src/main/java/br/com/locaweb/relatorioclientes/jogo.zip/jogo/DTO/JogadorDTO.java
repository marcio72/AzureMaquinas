package br.com.locaweb.relatorioclientes.jogo.DTO;


import java.util.List;

public class JogadorDTO {
        
        public String jogador;
        public int cartaIndex;
        public String nome;
    
    public void setJogador(final String jogador) {
        this.jogador = jogador;
    }
    
    public void setCartaIndex(final int cartaIndex) {
        this.cartaIndex = cartaIndex;
    }
    
    public void setNome(final String nome) {
        this.nome = nome;
    }
    
    public String getJogador() {
        return this.jogador;
    }
    
    public int getCartaIndex() {
        return this.cartaIndex;
    }
    
    public String getNome() {
        return this.nome;
    }
    
    public List<String> getCartas() {
        return this.cartas;
    }
    
    public void setCartas(final List<String> cartas) {
        this.cartas = cartas;
    }
    
    public List<String> cartas;
    
    }
    
    

