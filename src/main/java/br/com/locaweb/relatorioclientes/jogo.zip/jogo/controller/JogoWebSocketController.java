package br.com.locaweb.relatorioclientes.jogo.controller;

import br.com.locaweb.relatorioclientes.jogo.DTO.JogadorDTO;
import br.com.locaweb.relatorioclientes.jogo.service.JogoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
public class JogoWebSocketController {
    
    private final JogoService jogoService;
    private final SimpMessagingTemplate template;
    
    public JogoWebSocketController(JogoService jogoService, SimpMessagingTemplate template) {
        this.jogoService = jogoService;
        this.template = template;
    }
    
    @MessageMapping("/jogar")
    public void jogar(JogadorDTO jogada, SimpMessageHeaderAccessor headers) {
        
        HttpSession session = (HttpSession) headers
                                                    .getSessionAttributes()
                                                    .get("HTTP_SESSION");
        
        String nomeJogador = (String) session.getAttribute("jogador");
        
        jogoService.jogarCarta(nomeJogador, jogada.getCartaIndex());
        
        template.convertAndSend("/topic/estado", jogoService.getEstado());
    }
}
