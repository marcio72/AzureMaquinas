-- Vínculo chave <-> máquina (com histórico).
-- Rode ANTES de subir o backend novo. O ddl-auto=update até cria a tabela,
-- mas a FK pra "maquina" falha se o tipo do id não bater (maquina é tabela legada).
--
-- 1) Confira o tipo de maquina.id:
--      SHOW CREATE TABLE maquina;
--    Se for INT, troque "BIGINT" por "INT" na coluna maquina_id abaixo
--    (mesmo sinal: se lá for INT UNSIGNED, use INT UNSIGNED aqui).
--
-- Datas em DATETIME sem fração de segundo: o espelho Access (via ODBC)
-- não lida bem com DATETIME(6).

CREATE TABLE IF NOT EXISTS maquina_chave (
  id               BIGINT       NOT NULL AUTO_INCREMENT,
  maquina_id       INT          NOT NULL,          -- INT: igual ao maquina.id (int(11))
  chave_id         BIGINT       NOT NULL,
  uso              VARCHAR(20)  NOT NULL,          -- COFRE, TAMPA, CADEADO, OUTRO
  ativo            BIT(1)       NOT NULL DEFAULT b'1',
  vinculado_em     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  desvinculado_em  DATETIME     NULL,
  observacao       VARCHAR(255) NULL,
  PRIMARY KEY (id),
  KEY idx_maqchave_maquina (maquina_id, ativo),
  KEY idx_maqchave_chave   (chave_id, ativo),
  CONSTRAINT fk_maqchave_maquina FOREIGN KEY (maquina_id) REFERENCES maquina (id),
  CONSTRAINT fk_maqchave_chave   FOREIGN KEY (chave_id)   REFERENCES chave (id)
);
